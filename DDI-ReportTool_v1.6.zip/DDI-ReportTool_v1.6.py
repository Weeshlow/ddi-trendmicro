# -*- encoding: windows-1250
import zipfile
import os
import datetime
import csv, sqlite3
import re
#import operator
#from operator import itemgetter
#from ConfigParser import SafeConfigParser
#import shutil
#import time
#import json
import argparse
#import codecs
import operator
import requests, time


# TODO: clean up html (spacing>)
# TODO: add sections for C2 detailed information and/or output to txt files in output directory
# TODO: Need more details on email - descriptions/counts, top: recipients, subjects, attachments vs urls


def get_fieldnames(path_to_csv_file):
    fieldnames = []
    with open(path_to_csv_file) as f:
        reader = csv.reader(f)
        fieldnames = next(reader)
    return fieldnames


def create_output_dir(company_name, timestamp):
    cwd = os.getcwd()
    output_dir = company_name + "_" + timestamp
    output_dir_path = os.path.join(cwd, output_dir)
    if not os.path.exists(output_dir_path):
        os.makedirs(output_dir_path)
    print "Creating directory to hold script output at: {0}".format(output_dir_path)
    return output_dir_path

def extract_zip_to_dir(all_detection, extract_dir):
    try:
        with zipfile.ZipFile(all_detection, "r") as z:
            z.extractall(extract_dir)
        print "Unzipping {0} to {1}.".format(all_detection, extract_dir)
    except Exception,e:
        print "Error unzipping {0} to {1}.  Please ensure that this is a valid 'all_detection.zip' archive.".format(all_detection, extract_dir)
        print e
        exit(0)
    return

def open_csv(path_to_csv_file):
    alerts = []
    csvfile = open(path_to_csv_file, 'rU')
    reader = csv.DictReader(csvfile)
    counter = 1
    for row in reader:
        counter = counter + 1
        try:
            alerts.append(row)
        except:
            pass
    return alerts

def create_SQLiteDB_from_CSV(db_column_names, output_dir_path, timestamp, company_name):
    sqlite_file = str(timestamp) + str(company_name) + 'db.sqlite'
    sqlite_file = sqlite_file.replace(" ", "_")
    sqlite_file_path = os.path.join(output_dir_path, sqlite_file)
    if os.path.exists(sqlite_file_path):
        os.remove(sqlite_file_path)
    my_conn = sqlite3.connect(sqlite_file_path)
    my_conn.text_factory = str
    my_cursor = my_conn.cursor()
    my_cursor.execute("CREATE TABLE log (" + db_column_names + ");")  # use your column names here
    my_conn.commit()
    return my_conn, my_cursor

######TESTING###############
#Global variables - should only need these if experimenting via the python REPL
company_name = 'TESTING'
all_detection_paths = [r'all_detection.zip']



# The following dictionary is used to map fields from the threats.csv and malicious_urls.csv files to common, expected keys.
# The key names found in the dictionary will be used to create the column names of the 'logs' table in SQLite.
# The idea is to be able to build reliable sql queries that work across multiple versions of the csv log format (ie: SP3, SP5, SPX...)
# Note:  Each time the csv format changes in the future, we'll need to adjust the 'col_field_map' dictionary as well as the
# 'create_col_field_mapping' def (which updates the value of a given key based on the fieldnames available in the respetive csv file.)
col_field_map = {
'Time': '', # Usually 'Date/Timestamp', but sometimes hex characters get injected into this field (ie:  '\xef\xbb\xbfDate/Timestamp')
'Detection_Severity': 'Detection Severity',  # This is called 'Severity' in older logs
'Detection_Type': 'Detection Type',
'Detection_Name': 'Detection Name',
'Threat_Description': 'Threat Description',  # This is called 'Description' in older logs
'Source_IP': 'Source IP',
'Destination_IP': 'Destination IP',
'Protocol': 'Protocol',
'File_Name': 'File Name',
'Protocol_Group': 'Protocol Group',
'Destination_Port': 'Destination Port',
'Bot_Url': 'Bot Url',
'Source_Port': 'Source Port',
'Domain_Name': 'Domain Name',
'Hostname': 'Hostname',
'Rule_ID': 'Rule ID',
'File_Extension': 'File Extension',
'True_File_Type': 'True File Type',
'File_Size': 'File Size',
'Recipient': 'Recipient',
'Hasqfile': 'Hasqfile',
'Filenameinarc': 'Filenameinarc',
'Destination_Hostname': 'Destination Hostname',
'Source_Hostname': 'Source Hostname',
'BOT_Command': 'BOT Command',
'Interested_Ip': 'Interested Ip',  
'Peer_Ip': 'Peer Ip',
'Hasdtasres': 'Hasdtasres',
'Sha1': 'Sha1',
'User_Agent': 'User Agent',
'Sender': 'Sender',
'Email_Subject': 'Email Subject',   # This is called 'Subject' in older logs
'URL': 'URL',
'Sha1InArc': 'Sha1InArc',
'AttachmentFileName': 'AttachmentFileName',
'AttachmentFileSize': 'AttachmentFileSize',
'AttachmentFileType': 'AttachmentFileType',
'AttachmentSHA1': 'AttachmentSHA1',
'ccca_flag': 'ccca_flag',
'ccca_risklevel': 'ccca_risklevel',
'ccca_destinationformat': 'ccca_destinationformat',
'ccca_destination': 'ccca_destination',
'ccca_detectionsource': 'ccca_detectionsource',
'ece_severity': 'ece_severity',
'attack_phase': 'attack_phase',
'Notable_Object': 'Notable Object',  # This is called 'remarks' in older logs
'cc_server': 'cc_server',
'cc_servertype': 'cc_servertype',
'FileTypeInArc': 'FileTypeInArc',
'Common_Threat_Family': 'Common_Threat_Family',
'isAptRelated': 'isAptRelated',
'aptGroup': 'aptGroup',
'aptCampaign': 'aptCampaign',
'Reference': 'Reference',
'HTTP_Referer': 'HTTP Referer',
'Threat_(Virtual_Analyzer)': 'Threat (Virtual Analyzer)'
}


def create_col_field_mapping(csv_path):
    tcsv = open(csv_path)
    #print "opened successfully"
    dr = csv.reader(tcsv)
    fieldnames = next(dr)
    for f in fieldnames:
        if f == None:
            pass
        if 'Timestamp' in f:  # Sometimes the Timestamp field has leading hex characters in it.  This helps resolve the issue.
            col_field_map['Time'] = f
    for f in fieldnames:
        if 'Severity' in f:   # SP3 and before use 'Severity' instead of the newer 'Detection Severity'
            col_field_map['Detection_Severity'] = f  
    for f in fieldnames:
        if 'Description' in f:  # SP3 and before use 'Description' instead of the newer 'Threat Description'
            col_field_map['Threat_Description'] = f 
    for f in fieldnames:
        if f == "Threat":    # The malicious_urls.csv uses 'Threat' instead of 'Threat Description'
            col_field_map['Threat_Description'] = f     
    for f in fieldnames:
        if 'Subject' in f:   # SP3 and before use 'Subject' instead of 'Email Subject'
            col_field_map['Email_Subject'] = f  
    for f in fieldnames:
        if ('Notable' in f or 'remarks' in f):   # SP3 and before use 'remarks' instead of 'Notable'
            col_field_map['Notable_Object'] = f 
    tcsv.close()

def get_db_column_names():
    return "'" + "','".join(col_field_map.keys()) + "'"

def get_values(db_column_names):
    columns_list = db_column_names.split(",")
    values = ""
    for i in columns_list:
        value = ":" + col_field_map[i.replace("'", '')] + ","
        values += value
    values = values.rstrip(",")
    return values

def get_value_placeholders(db_column_names):
    columns_list = db_column_names.split(",")
    return ', '.join('?' * len(columns_list))

def get_column_list(db_column_names):
    column_list = []
    temp = db_column_names.split(",")
    for i in temp:
        column_list.append(i.strip("'").replace("_", " "))
    return column_list


def import_threats_csv(threats_csv, my_conn, my_cursor, db_column_names, db_column_list): 
    value_placeholders = get_value_placeholders(db_column_names)
    my_sql_insert_threat = "INSERT INTO log ({}) VALUES ({})".format(db_column_names, value_placeholders)
    tcsv = open(threats_csv)
    dr = csv.DictReader(tcsv)
    for row in dr:
        #print row
        values_list = []
        for i in db_column_list:
            try:
                values_list.append(row[col_field_map[i]])
            except KeyError, e:
                values_list.append("no info") # The field doesn't exist in the CSV (probably due to an older version of code)
                continue
        my_cursor.execute(my_sql_insert_threat, values_list)
    my_conn.commit()
    tcsv.close()    

def import_url_csv(malicious_urls_csv, my_conn, my_cursor, db_column_names, db_column_list): 
    value_placeholders = get_value_placeholders(db_column_names)
    my_sql_insert_threat = "INSERT INTO log ({}) VALUES ({})".format(db_column_names, value_placeholders)
    url_csv = open(malicious_urls_csv)
    dr = csv.DictReader(url_csv)
    for row in dr:
        #print row
        values_list = []
        for i in db_column_list:
            if col_field_map[i] in row:
                values_list.append(row[col_field_map[i]])
            else:
                values_list.append("")
        #print ""
        #print my_sql_insert_threat
        #print values_list
        my_cursor.execute(my_sql_insert_threat, values_list)
    my_conn.commit()
    url_csv.close()   

def purge_rule_ids(my_conn, my_cursor):
    my_cursor.execute("DELETE FROM log WHERE Rule_ID=28 or Rule_ID=29 or Rule_ID=40 or Rule_ID=52;")
    my_conn.commit()

def get_alert_count(my_cursor):
    my_cursor.execute("SELECT COUNT(*) FROM log;")
    result = my_cursor.fetchone()
    print "Total logs (after purging) = " + str(result[0])

def get_first_last_alert_dates(my_cursor):
    my_cursor.execute("SELECT MIN(Time) FROM log;")
    first_alert_date = my_cursor.fetchone()
    first_alert_date = str(first_alert_date[0])
    first_alert_date = first_alert_date[:10]
    my_cursor.execute("SELECT MAX(Time) FROM log;")
    last_alert_date = my_cursor.fetchone()
    last_alert_date = str(last_alert_date[0])
    last_alert_date = last_alert_date[:10]
    return first_alert_date, last_alert_date

def get_alert_count(my_cursor):
    my_cursor.execute("SELECT COUNT(*) FROM log;")
    result = my_cursor.fetchone()
    return result[0]

def get_endpoint_infections(my_cursor):
    my_cursor.execute('select distinct(Interested_IP) from log where attack_phase like "%Communication%";')
    results = my_cursor.fetchall()
    endpoint_infections = []
    for r in results:
        #print r[0]
        endpoint_infections.append(r[0])
    return endpoint_infections

def get_hosts_with_lateral_movment_alerts(my_cursor):
    my_cursor.execute('select distinct(Interested_IP) from log where attack_phase="Lateral Movement";')
    results = my_cursor.fetchall()
    hosts_with_lateral_movment = []
    for r in results:
        #print r[0]
        hosts_with_lateral_movment.append(r[0])
    return hosts_with_lateral_movment

def get_ransomware_alerts(my_cursor):
    """Returns a list of ransomware-related alerts."""
    my_cursor.execute('''
    select * from log WHERE UPPER(Threat_Description) LIKE '%LOCK%'
    OR UPPER(Threat_Description) LIKE '%RANSOM%'
    OR UPPER(Threat_Description) LIKE '%CRYP%'
    OR UPPER(Threat_Description) LIKE '%MATSNU%'
    OR UPPER(Threat_Description) LIKE '%NEMUCOD%'
    OR UPPER(Threat_Description) LIKE '%REVETON%'
    OR UPPER(Threat_Description) LIKE '%TROJ_ACCDFISA%'
    OR UPPER(Threat_Description) LIKE '%TROJ_CRIBIT%'
    OR UPPER(Threat_Description) LIKE '%TROJ_KOLLAH%'
    OR UPPER(Threat_Description) LIKE '%TROJ_KOVTER%'
    OR UPPER(Threat_Description) LIKE '%TROJ_PGPCODER%'
    OR UPPER(Threat_Description) LIKE '%TROJ_POSHCODER%'
    OR UPPER(Threat_Description) LIKE '%TSPY_KOVTER%'
    OR UPPER(Threat_Description) LIKE '%VBUZKY%'
    OR UPPER(Threat_Description) LIKE '%_CERBER%'
    ;''')
    results = my_cursor.fetchall()
    ransomware_alerts = []
    for r in results:
        # print r[0]
        ransomware_alerts.append(r)
    return ransomware_alerts

def get_total_email_alerts(my_cursor):
    '''Returns a list of all smtp alerts (less messages with "spam" in the recipient or subject line).'''
    my_cursor.execute('''
    select * from log where protocol='SMTP'
    and Recipient NOT LIKE '%spam%'
    and Email_Subject NOT LIKE '%spam%'
    ;''')
    results = my_cursor.fetchall()
    email_alerts = []
    for r in results:
        # print r[0]
        email_alerts.append(r)
    return email_alerts

def get_ransomware_alert_counts(my_cursor):
    my_cursor.execute('''
    select distinct(Threat_Description), count(*) from log WHERE UPPER(Threat_Description) LIKE '%LOCK%'
    OR UPPER(Threat_Description) LIKE '%RANSOM%'
    OR UPPER(Threat_Description) LIKE '%CRYP%'
    OR UPPER(Threat_Description) LIKE '%MATSNU%'
    OR UPPER(Threat_Description) LIKE '%NEMUCOD%'
    OR UPPER(Threat_Description) LIKE '%REVETON%'
    OR UPPER(Threat_Description) LIKE '%TROJ_ACCDFISA%'
    OR UPPER(Threat_Description) LIKE '%TROJ_CRIBIT%'
    OR UPPER(Threat_Description) LIKE '%TROJ_KOLLAH%'
    OR UPPER(Threat_Description) LIKE '%TROJ_KOVTER%'
    OR UPPER(Threat_Description) LIKE '%TROJ_PGPCODER%'
    OR UPPER(Threat_Description) LIKE '%TROJ_POSHCODER%'
    OR UPPER(Threat_Description) LIKE '%TSPY_KOVTER%'
    OR UPPER(Threat_Description) LIKE '%VBUZKY%'
    OR UPPER(Threat_Description) LIKE '%_CERBER%'
    GROUP BY Threat_Description
    ORDER BY count(*) DESC
    ;''')
    results = my_cursor.fetchall()
    ransomware_alert_counts = []
    for r in results:
        # print r[0]
        ransomware_alert_counts.append(r)
    return ransomware_alert_counts

def get_hosts_with_ransomware(my_cursor):
    '''Returns a list of hosts (Intersted_IP) that have ransomware alerts'''
    #TODO Need to find a way to include alerts that don't have a value in the Interested_IP field
    my_cursor.execute('''
    select distinct(Interested_IP) from log WHERE UPPER(Threat_Description) LIKE '%LOCK%'
    OR UPPER(Threat_Description) LIKE '%RANSOM%'
    OR UPPER(Threat_Description) LIKE '%CRYP%'
    OR UPPER(Threat_Description) LIKE '%MATSNU%'
    OR UPPER(Threat_Description) LIKE '%NEMUCOD%'
    OR UPPER(Threat_Description) LIKE '%REVETON%'
    OR UPPER(Threat_Description) LIKE '%TROJ_ACCDFISA%'
    OR UPPER(Threat_Description) LIKE '%TROJ_CRIBIT%'
    OR UPPER(Threat_Description) LIKE '%TROJ_KOLLAH%'
    OR UPPER(Threat_Description) LIKE '%TROJ_KOVTER%'
    OR UPPER(Threat_Description) LIKE '%TROJ_PGPCODER%'
    OR UPPER(Threat_Description) LIKE '%TROJ_POSHCODER%'
    OR UPPER(Threat_Description) LIKE '%TSPY_KOVTER%'
    OR UPPER(Threat_Description) LIKE '%VBUZKY%'
    OR UPPER(Threat_Description) LIKE '%_CERBER%'
    ;''')
    results = my_cursor.fetchall()
    hosts_with_ransomware = []
    for r in results:
        if r[0] != '':
            hosts_with_ransomware.append(r[0])
    return hosts_with_ransomware

def get_host_ransomware_descriptions_dict(my_cursor, host):
    '''Returns a dictionary of ransomware alert descriptions for a host'''
    sql_string = '''
    select distinct(Threat_Description), count(*) from log where Interested_IP="{host}" group by Threat_Description order by count(*) desc;
    '''.format(host=host)
    my_cursor.execute(sql_string)
    results = my_cursor.fetchall()
    host_dict = {}
    for threat_description_row in results:
        host_dict[threat_description_row[0]] = threat_description_row[1]
    return host_dict

def get_c2_alerts(my_cursor):
    '''Returns a list of all c2 alerts.'''
    my_cursor.execute('''
    select * from log where attack_phase LIKE '%Communication%'
    ;''')
    results = my_cursor.fetchall()
    c2_alerts = []
    for r in results:
        # print r[0]
        c2_alerts.append(r)
    return c2_alerts

def get_breached_hosts(my_cursor):
    '''Returns a list of breached hosts'''
    my_cursor.execute('''
    select distinct(Interested_IP) from log where attack_phase like "%Communication%";
    ''')
    results = my_cursor.fetchall()
    breached_hosts = []
    for r in results:
        breached_hosts.append(r[0])
    return breached_hosts

def get_host_indicators_dict(my_cursor, host):
    '''Returns a dictionary of attack_phase indicators for a host'''
    sql_string = '''
    select distinct(attack_phase), count(*) from log where Interested_IP="{host}" group by attack_phase order by count(*) desc;
    '''.format(host=host)
    my_cursor.execute(sql_string)
    results = my_cursor.fetchall()
    host_dict = {}
    for indicator_row in results:
        if indicator_row[0] == '':
            host_dict["Unknown"] = indicator_row[1]
        else:
            host_dict[indicator_row[0]] = indicator_row[1]
    return host_dict

def get_protocols_dict(my_cursor):
    '''Returns a dictionary of protocols and their respective alert counts'''
    sql_string = '''
    select distinct(Protocol), count(*) from log group by Protocol order by count(*) desc;
    '''
    my_cursor.execute(sql_string)
    results = my_cursor.fetchall()
    protocols_dict = {}
    for protocol in results:
        protocols_dict[protocol[0]] = protocol[1]
    return protocols_dict

def get_critical_threat_descriptions(my_cursor):
    '''Returns a list of Threat_Descriptions with ece_severities of critical'''
    sql_string = '''
    select distinct(Threat_Description), count(*) from log where ece_severity = "8 Critical" group by Threat_Description order by count(*) desc;
    '''
    my_cursor.execute(sql_string)
    results = my_cursor.fetchall()
    crit_threat_desc = []
    for r in results:
        crit_threat_desc.append(r[0])
    return crit_threat_desc   

def get_crit_malware_dict(my_cursor, threat_desc):
    '''Returns a dictionary of critical threat descriptions and associated counds and hosts affected'''
    #first get the count
    sql_string = '''
    select count(*) from log where Threat_Description = "{threat_desc}";
    '''.format(threat_desc=threat_desc)
    my_cursor.execute(sql_string)
    result = my_cursor.fetchall()
    count = result[0][0]
    sql_string = '''
    select distinct(Interested_IP) from log where Threat_Description = "{threat_desc}";
    '''.format(threat_desc=threat_desc)
    my_cursor.execute(sql_string)
    result = my_cursor.fetchall() 
    hosts_affected_string = ""
    for host in result:
        hosts_affected_string += "{host}, ".format(host=host[0])
    hosts_affected_string = hosts_affected_string[:-2]
    crit_malware_dict = {"threat_desc": threat_desc, "count": count, "hosts_affected": hosts_affected_string}
    return crit_malware_dict

def get_c2_info_dict(my_cursor):
    '''Returns a dictionary containing C2 information'''
    sql_string = '''
    select distinct(cc_server) from log where attack_phase like "%Communication%"
    '''
    my_cursor.execute(sql_string)
    result = my_cursor.fetchall()
    c2_destinations = []
    for dest in result:
        c2_destinations.append(dest[0])
    sql_string = '''
    select distinct(Interested_IP) from log where attack_phase like "%Communication%"
    '''
    my_cursor.execute(sql_string)
    result = my_cursor.fetchall()    
    hosts_with_callback_alerts = []
    for host in result:
        hosts_with_callback_alerts.append(host[0])
    #TODO:  Need to test the query with a dataset that contains Suspicious Object detections
    sql_string = '''
    select distinct(Destination_IP) from log where attack_phase like "%Communication%" and threat_description like "%Suspicious Objects%"
    '''
    my_cursor.execute(sql_string)
    result = my_cursor.fetchall()    
    so_c2_destinations = []
    for dest in result:
        so_c2_destinations.append(dest[0])
    c2_info_dict = {'c2_destinations': c2_destinations,
                 'hosts_with_callback_alerts': hosts_with_callback_alerts,
                 'so_c2_destinations': so_c2_destinations}
    return c2_info_dict

def get_threat_desc_overview(my_cursor):
    '''Returns a dictionary containing each threat description and its corresponding count'''
    sql_string = '''
    select distinct(Threat_Description), count(*) from log group by Threat_Description order by count(*) desc;
    '''
    my_cursor.execute(sql_string)
    results = my_cursor.fetchall()
    threat_desc_dict = {}
    for threat_desc in results:
        threat_desc_dict[threat_desc[0]] = threat_desc[1]
    threat_desc_dict_sorted = sorted(threat_desc_dict.items(), key=operator.itemgetter(1), reverse=True)    
    return threat_desc_dict_sorted

def get_va_detections(my_cursor):
    '''Returns a list of dictionaries containing information on threats discovered via Virtual Analysis'''
    sql_string = '''
    select Threat_Description,File_Name,Hostname, SHA1, Protocol, URL, Interested_IP from log where hasdtasres="Has Report";
    '''
    my_cursor.execute(sql_string)
    results = my_cursor.fetchall() 
    list_of_zd_dict = []
    for zd in results:
        zero_day_dict = {}
        zero_day_dict['Threat_Description'] = zd[0]
        zero_day_dict['File_Name'] = zd[1]
        zero_day_dict['Hostname'] = zd[2]
        zero_day_dict['SHA1'] = zd[3]
        zero_day_dict['Protocol'] = zd[4]
        zero_day_dict['URL'] = zd[5]
        zero_day_dict['InterestedHost'] = zd[6]
        list_of_zd_dict.append(zero_day_dict)
    return list_of_zd_dict

def get_unique_count_of_zero_days(my_cursor):
    '''Returns a count of unique zero-days (based on unique SHA1 hash)'''
    sql_string = '''
    select count(distinct(SHA1)) from log where hasdtasres="Has Report";    
    '''
    my_cursor.execute(sql_string)
    results = my_cursor.fetchall()
    return results

def get_unique_list_of_zero_days(my_cursor):
    '''Returns a count of unique zero-days (based on unique SHA1 hash)'''
    sql_string = '''
    select distinct(SHA1) from log where hasdtasres="Has Report";    
    '''
    my_cursor.execute(sql_string)
    results = my_cursor.fetchall()
    return results    

def main():
    timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    output_dir_path = create_output_dir(company_name, timestamp)
    num_archives = 1
    for all_detection in all_detection_paths:
        #print all_detection
        extract_dir = os.path.join(output_dir_path, str(num_archives))
        if not os.path.exists(extract_dir):
            os.makedirs(extract_dir)
        extract_zip_to_dir(all_detection, extract_dir)
        threats_csv = os.path.join(extract_dir, "threats.csv")
        malicious_urls_csv = os.path.join(extract_dir, "malicious_urls.csv")
        #fieldnames = get_fieldnames(threats_csv)
        global my_conn
        global my_cursor
        db_column_names = get_db_column_names()
        #print db_column_names
        my_conn, my_cursor = create_SQLiteDB_from_CSV(db_column_names,output_dir_path, timestamp, company_name)
        db_column_list = col_field_map.keys()
        create_col_field_mapping(threats_csv)
        import_threats_csv(threats_csv, my_conn, my_cursor, db_column_names, db_column_list)  
        create_col_field_mapping(malicious_urls_csv)
        import_url_csv(malicious_urls_csv, my_conn, my_cursor, db_column_names, db_column_list)
        num_archives += 1    
    purge_rule_ids(my_conn, my_cursor)
    endpoint_infections_list = get_endpoint_infections(my_cursor)
    html = '''
<!DOCTYPE html>
<html>
<head>
<style>
table, h1, p {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
</head>
<body>
    '''
    print ""
    print "*" * 80
    print "BREACH ASSESSMENT SUMMARY"
    print "*" * 80
    print ""
    alert_count = get_alert_count(my_cursor)
    print "Total logs (after purging) =                       {0}".format(alert_count)
    print ""
    first_alert_date, last_alert_date = get_first_last_alert_dates(my_cursor)
    print "The period of this report was from " + str(first_alert_date) + " to " + str(last_alert_date)
    print ""
    print "Endpoint Infections Count:                         {0}".format(len(endpoint_infections_list))
    email_alerts = get_total_email_alerts(my_cursor)
    print ""
    print "Number of Weaponized email alerts (spam excluded): {0}".format(len(email_alerts))   
    ransomware_alerts = get_ransomware_alerts(my_cursor)
    print ""
    print "Number of ransomware alerts:                       {0}".format(len(ransomware_alerts))
    #ransomware_alert_counts = get_ransomware_alert_counts(my_cursor)
    print""
    hosts_with_lateral_movment = get_hosts_with_lateral_movment_alerts(my_cursor)
    print "Number of hosts with Lateral Movement Alerts:      {0}".format(len(hosts_with_lateral_movment))
    print ""
    c2_alerts = get_c2_alerts(my_cursor)
    print "Number of c2 alerts:                               {0}".format(len(c2_alerts))
    print ""
    va_results = get_unique_count_of_zero_days(my_cursor)[0][0]
    print "Number of zero-day malware:                        {0}".format(va_results)
    print ""
    print "*" * 80
    
    html += '''
    <h1>BREACH ASSESSMENT SUMMARY</h1>
    <table>
      <tr>
        <td>Total logs (after purging)</td>
        <td>{alert_count}</td>
      </tr>
      <tr>
        <td>Start Date</td>
        <td>{start_date}</td>
      </tr>
        <tr>
        <td>End Date</td>
        <td>{end_date}</td>
      </tr>
      <tr>
        <td>Endpoint Infections</td>
        <td>{endpoint_infections}</td>
      </tr>
      <tr>
        <td>Weaponized Email</td>
        <td>{weaponized_email}</td>
      </tr>
      </tr>
      <tr>
        <td>Ransomware</td>
        <td>{ransomware}</td>
      </tr>
      </tr>
        <tr>
        <td>Lateral Movement</td>
        <td>{lateral_movement}</td>
      </tr>
      </tr>
        <tr>
        <td>Command and Control</td>
        <td>{command_and_control}</td>
      </tr>
      </tr>
        <tr>
        <td>VA Discoveries</td>
        <td>{va_discoveries}</td>
      </tr>
    </table>
        '''.format(alert_count=alert_count,
                   start_date=str(first_alert_date),
                   end_date=str(last_alert_date),
                   endpoint_infections=len(endpoint_infections_list),
                   weaponized_email=len(email_alerts),
                   ransomware=len(ransomware_alerts),
                   lateral_movement=len(hosts_with_lateral_movment),
                   command_and_control=len(c2_alerts),
                   va_discoveries=va_results)    
    
    print "BREACHED HOSTS"
    print "*" * 80
    print ""
    html += '''
    <h1>BREACHED HOSTS</h1>
    <table>
    <tr><th>Host</th><th>Indicators</th></tr>
    '''
    breached_hosts_list = get_breached_hosts(my_cursor)
    print ""
    print "{host:35s} | {indicators_string}".format(host="Host", indicators_string="indicators_string")
    for host in breached_hosts_list:
        host_dict = get_host_indicators_dict(my_cursor, host)
        indicators_string = ""
        for indicator_type, value in host_dict.iteritems():
            indicators_string += "{indicator_type}: {value}, ".format(indicator_type=indicator_type, value=value)
        indicators_string = indicators_string[:-2]
        print "{host:35s} | {indicators_string}".format(host=host, indicators_string=indicators_string)
        html += "<tr><td>{host}</td><td>{indicators_string}</td>\n".format(host=host, indicators_string=indicators_string)
    html += "</table>\n"
    
    print ""
    print "*" * 80
    print "RANSOMWARE"
    print "*" * 80
    print ""    
    print ""
    html += '''
    <h1>RANSOMWARE</h1>
    <table>
    <tr><th>Host</th><th>Ransomware Alert Descriptions</th></tr>\n
    '''
    hosts_with_ransomware_list = get_hosts_with_ransomware(my_cursor)
    print "{host:25s} | {ransom_description_string}".format(host="Host", ransom_description_string="ransom_description_string")
    for host in hosts_with_ransomware_list:
        host_dict = get_host_ransomware_descriptions_dict(my_cursor, host)
        ransom_description_string = ""
        for ransom_desc, value in host_dict.iteritems():
            ransom_description_string += "{ransom_desc}: {value}, ".format(ransom_desc=ransom_desc, value=value)
        ransom_description_string = ransom_description_string[:-2]
        print "{host:25s} | {ransom_description_string}".format(host=host, ransom_description_string=ransom_description_string)
        html += "<tr><td>{host}</td><td>{ransom_description_string}</td>\n".format(host=host, ransom_description_string=ransom_description_string)
    html += "</table>"        
    
    print ""
    print "*" * 80
    print "ZERO-DAY MALWARE DISCOVERED"
    print "*" * 80 
        
    list_of_va_detections_dicts = get_va_detections(my_cursor)
    print ""
    print "Total VA Discoveries:                        {0}".format (len(list_of_va_detections_dicts))
    print ""
    '''print "{File_Name:35s} | {SHA1:40s} | {InterestedHost:40s} | {Hostname:35s} | {Protocol:10s} | {Threat_Description} ".format(
            File_Name='File_Name', SHA1='SHA1', InterestedHost='InterestedHost',
            Threat_Description='Threat_Description', Hostname='Hostname', Protocol='Protocol')  '''
    
    processed_sha1 = []
    zd_sha1 = []
    known_sha1 = []
    for va_dict  in list_of_va_detections_dicts:
        # Show a unique listing (by SHA1) of all VA detections
        if va_dict['SHA1'] not in processed_sha1:
            processed_sha1.append(va_dict['SHA1'])
            print "{File_Name:35s} | {SHA1:40s} | {InterestedHost:40s} | {Hostname:35s} | {Protocol:10s} | {Threat_Description} ".format(
            File_Name=va_dict['File_Name'], SHA1=va_dict['SHA1'], InterestedHost=va_dict['InterestedHost'],
            Threat_Description=va_dict['Threat_Description'], Hostname=va_dict['Hostname'], Protocol=va_dict['Protocol'])
    
    print "\nTotal UNIQUE VA Discoveries (based on SHA1): {0}\n".format (len(processed_sha1))
    if skip_vt.lower() == "false":
        sha1_list = processed_sha1 # Making a copy of the SHA1 list that we need to check against VT.  We'll be popping from this list.
        zero_days = []
        known_malware = []
        #vt_results_dict = {}
        iterations_needed = (len(sha1_list)/4)
        
        if len(sha1_list) > 4:
            print "There are {0} SHA1 values that we need to check against the VT API.\n".format(len(sha1_list))
            print "We can only submit in batches of 4 SHA1 values at a time due to restrictions of the VT API key we're using.\n"
            print "We'll need to make {0} batch requests to check all {1} SHA1 values\n".format(iterations_needed + 1, len(sha1_list))
            for iteration in range(iterations_needed):
                print "Starting iteration {0} of {1}".format(iteration + 1, iterations_needed + 1)
                #print "sha1_list length: {0}".format(len(sha1_list))
                vt_batch = []
                for i in range(4):
                    vt_batch.append(sha1_list.pop(0))
                resource_string = ",".join(vt_batch)
                print "Submitting the following SHA1 values to VirusTotal:\n"
                print resource_string
                params = {'apikey': 'a0fbca61bdcc5a3046c8f629fb562dd0a2e80e21eeab5ff38230b8249b9a73cc', 'resource': resource_string}
                headers = {
                    "Accept-Encoding": "gzip, deflate",
                    "User-Agent" : "gzip,  My Python requests library example client or username"
                }
                response = requests.get('https://www.virustotal.com/vtapi/v2/file/report',
                                        params=params, headers=headers)
                json_response = response.json()
                #print json_response
                for i in json_response:
                    #vt_results_dict[i['resource']] = i['response_code']
                    if i['response_code'] == 0:
                        zero_days.append(i['resource'])
                    else:
                        known_malware.append(i['resource'])
                    #print "{0}: {1}".format(i['resource'], i['response_code'])
                print "\nsleeping for 20 seconds..\n\n"
                time.sleep(20)
        
             
        if len(sha1_list) > 0:
            #print "sha1_list length: {0}".format(len(sha1_list))
            resource_string = ",".join(sha1_list)
            print "Submitting the following SHA1 values to VirusTotal:\n"
            print resource_string
            params = {'apikey': 'a0fbca61bdcc5a3046c8f629fb562dd0a2e80e21eeab5ff38230b8249b9a73cc', 'resource': resource_string}
            headers = {
                    "Accept-Encoding": "gzip, deflate",
                    "User-Agent" : "gzip,  My Python requests library example client or username"
                }
            response = requests.get('https://www.virustotal.com/vtapi/v2/file/report',
                                        params=params, headers=headers)
            json_response = response.json()
            #print json_response
            if type(json_response) is list:
                for i in json_response:
                    #vt_results_dict[i['resource']] = i['response_code']
                    if i['response_code'] == 0:
                        zero_days.append(i['resource'])
                    else:
                        known_malware.append(i['resource'])
                    print "{0}: {1}".format(i['resource'], i['response_code'])
            else:
                #vt_results_dict[json_response['resource']] = json_response['response_code']
                if json_response['response_code'] == 0:
                    zero_days.append(json_response['resource'])
                else:
                    known_malware.append(json_response['resource'])
                print "{0}: {1}".format(json_response['resource'], json_response['response_code'])           
        
        print "Number of Zero Days:      {0}".format(len(zero_days))
        print "Number of Known Malware:  {0}".format(len(known_malware))
        html += '''
        <h1>Zero-Day Malware Discovered</h1>
        <p>Total VA Discoveries: {total_va_discoveries}</p>
        <p>Total UNIQUE VA Discoveries (based on SHA1): {total_unique_sha1}
        <p>Total Zero-Day Discoveries: {total_zeroday_discoveries}</p>
        <table>
        <tr><th>File/Object</th><th>SHA1</th><th>Hosts Affected</th></tr>
        '''.format(total_va_discoveries=len(list_of_va_detections_dicts),
                   total_unique_sha1=len(processed_sha1),
                   total_zeroday_discoveries=len(zero_days))
        print "ZERO-DAY MALWARE DETAILS:\n\n"
        for zd in zero_days:
            for va_dict in list_of_va_detections_dicts:
                if zd == va_dict['SHA1']:
                    html += '''
                    <tr><td>{File_Name}</td><td>{SHA1}</td><td>{InterestedHost}</td></tr>\n'''.format(File_Name=va_dict['File_Name'],
                                                                                                    SHA1=va_dict['SHA1'],
                                                                                                    InterestedHost=va_dict['InterestedHost'])   # Note:  may have more than 1 host affected.   
                    print "{File_Name:35s} | {SHA1:40s} | {InterestedHost:40s}".format(File_Name=va_dict['File_Name'],
                                                                                           SHA1=va_dict['SHA1'],
                                                                                           InterestedHost=va_dict['InterestedHost'])
                    break
        
        html += "</table>"
        
    print ""
    print "*" * 80
    print "PROTOCOL DISTRIBUTION"
    print "*" * 80
    print ""    
    protocols_dict = get_protocols_dict(my_cursor)
    print "{protocol:35s} | {count}".format(protocol="Protocol", count="Count")
    html += '''
    <h1>PROTOCOL DISTRIBUTION</h1>
    <table>
    <tr><th>Protocol</th><th>Count</th></tr>
    '''    
    for protocol, count in protocols_dict.iteritems():
        print "{protocol:35s} | {count}".format(protocol=protocol, count=count)
        html += "<tr><td>{protocol}</td><td>{count}</td></tr>\n".format(protocol=protocol, count=count)
    html += "</table>"
    print ""
    '''print "Same info as above but in copy/paste form..."
    print "{protocol},{count}".format(protocol="Protocol", count="Count")
    for protocol, count in protocols_dict.iteritems():
        print "{protocol},{count}".format(protocol=protocol, count=count)'''
    
    print ""
    print ""
    print "*" * 80
    print "TOP CRITICAL MALWARE MAPPING"
    print "*" * 80
    print ""
    print "{threat_desc:75s} | {count:5s} | {hosts_affected}".format(threat_desc="Threat Description", 
                                                                     count="Count", 
                                                                         hosts_affected="Hosts Affected")  
    html += '''
    <h1>TOP CRITICAL MALWARE MAPPING</h1>
    <table>
    <tr><th>Threat Description</th><th>Count</th><th>Hosts Affected</th></tr>
    '''
    crit_threat_desc = get_critical_threat_descriptions(my_cursor)
    for threat_desc in crit_threat_desc:
        crit_malware_dict = get_crit_malware_dict(my_cursor, threat_desc)
        print "{threat_desc:75s} | {count:5d} | {hosts_affected}".format(threat_desc=threat_desc, 
                                                                          count=crit_malware_dict['count'], 
                                                                          hosts_affected=crit_malware_dict['hosts_affected'])
        html += "<tr><td>{threat_desc}</td><td>{count}</td><td>{hosts_affected}</td></tr>\n".format(threat_desc=threat_desc, 
                                                                          count=crit_malware_dict['count'], 
                                                                          hosts_affected=crit_malware_dict['hosts_affected'])
    html += "</table>"
    
    print ""
    print "*" * 80
    print "C2 DETECTIONS"
    print "*" * 80
    print ""
    c2_info_dict = get_c2_info_dict(my_cursor)
    print "Distinct C2 Destinations:  {0}".format(len(c2_info_dict['c2_destinations']))
    for dest in c2_info_dict['c2_destinations']:
        print "\t{dest}".format(dest=dest)
    print ""
    print "Hosts with Callback Alerts:  {0}".format(len(c2_info_dict['hosts_with_callback_alerts']))
    for host in c2_info_dict['hosts_with_callback_alerts']:
        print "\t{host}".format(host=host)
    print ""
    print "C2 Destinations Discovered Via Virtual Analysis (Suspicious Object Matches):    {0}".format(len(c2_info_dict['so_c2_destinations']))
    if len(c2_info_dict['so_c2_destinations']) == 0:
        print "\tNone"
    else:
        for dest in c2_info_dict['so_c2_destinations']:
            print "\t{dest}".format(dest=dest)
    html += '''
    <h1>C2 DETECTIONS</h1>
    <p>Distinct C2 Destinations:                                                    {0}</p>
    <p>Hosts with Callback Alerts:                                                  {1}</p>
    <p>C2 Destinations Discovered Via Virtual Analysis (Suspicious Object Matches): {2}</p>
    '''.format(len(c2_info_dict['c2_destinations']),
               len(c2_info_dict['hosts_with_callback_alerts']),
               len(c2_info_dict['so_c2_destinations']))
    # NOTE:  MIGHT WANT TO OUTPUT ALL C2 DESTINATIONS, HOSTS WITH C2 ALERTS AND SO C2 MATCHES
    
    print ""
    print "*" * 80
    print "THREAT DESCRIPTIONS | COUNTS"
    print "*" * 80
    print ""        
    threat_desc_list_of_tuples = get_threat_desc_overview(my_cursor)
    print "{threat_desc:75s} | {count}".format(threat_desc="Threat Description", count="Count")
    html += '''
    <h1>THREAT DESCRIPTIONS | COUNTS</h1>
    <table>
    <tr><th>Threat Description</th><th>Count</th></tr>
    '''    
    for threat_desc in threat_desc_list_of_tuples:
        print "{threat_desc:75s} | {count}".format(threat_desc=threat_desc[0], count=threat_desc[1])
        html += "<tr><td>{threat_desc}</td><td>{count}</td></tr>\n".format(threat_desc=threat_desc[0], count=threat_desc[1])
    html += "</table>"
    
    html += '''
</body>
</html>
    '''
    with open(os.path.join(output_dir_path, 'ddi-report-tool.html'), 'a') as outfile:
        outfile.write(html)
    
    

if __name__ == '__main__':
    parser = argparse.ArgumentParser(version='%(prog)s 1.2')
    parser.add_argument('-c', action='store', required=True, dest='company_name',
                        help='The Company Name for the report')
    parser.add_argument('-a', action='append', required=True, dest='all_detection_paths',
                        default=[],
                        help='The path to the all_detection.zip file(s).  This parameter can be specified multiple times',
                        )
    parser.add_argument('-x', action='store', required=False, dest='skip_vt',
                        default="false",
                        help='Specify whether or not to skip VirusTotal processing',
                        )    
    results = parser.parse_args()
    company_name = results.company_name
    all_detection_paths = results.all_detection_paths
    skip_vt = results.skip_vt
    print "INPUT PARAMETERS:"
    print 'Company Name          =', company_name
    print 'all_detection_path(s) =', "".join(all_detection_paths)
    print 'skip_vt               =', skip_vt
    print ""
    main()


'''
 SQL Queries:

 Lateral Movement Threat Descriptions with associated counts:
 SELECT distinct(Threat_Description), count(*) as `num` from log where attack_phase='Lateral Movement' group by Threat_Description;

 All Threat Descriptions with associated countes (sorted descending):
 SELECT distinct(Threat_Description), count(*) as `num` from log group by Threat_Description order by count(*) desc;


SELECT distinct(InterestedHost), count(*) from log where Threat_Description like '%CONFICKER%' group by InterestedHost;


SELECT distinct(InterestedHost), count(*) from log where Threat_Description like '%prevalence%' group by interestedhost order by count(*) desc;


SELECT Source_IP, Destination_IP, File_Name, Protocol_Group, URL, InterestedHost from log where Threat_Description like '%file with low prevalence%' order by interestedhost;


SELECT distinct(Protocol), count(*) from log group by Protocol order by count(*) desc;

#####################################################################################################################
SpearPhishing:
- Total SMTP-based alerts
select * from log where protocol='SMTP';
select count(*) from log where protocol='SMTP';
select * from log where protocol='SMTP' and ece_severity > "3";
Note: may want to ignore low severity alerts.
- Who is affected?
select recipient from log where (protocol='SMTP' or protocol='POP3' or protocol='IMAP') and ece_severity > "3";
Note: multiple recipients separated by ";"
- Where did the phishing emails come from?
select sender from log where (protocol='SMTP' or protocol='POP3' or protocol='IMAP') and ece_severity > "3";
Note: sender can be spoofed
How?
Subjects:
select email_subject from log where (protocol='SMTP' or protocol='POP3' or protocol='IMAP') and ece_severity > "3";
Attachments:

URLs:

need example data!!!

#######################################################################################################################
Zero Day Malware:
- Total Unique Malware

select * from log where Hasdtasres="Has Report" and ece_severity > "2" order by ece_severity desc;

select Detection_Severity, Threat_Description, Source_IP, Destination_IP, File_Name, Hostname, Filenameinarc, Hasdtasres, Sha1, Sha1InArc, URL, ece_severity, InterestedHost, Protocol  from log where Hasdtasres="Has Report" and ece_severity > "3";
select distinct(SHA1) from log where Hasdtasres="Has Report" and ece_severity > "2" order by ece_severity desc;
select distinct(File_Name) from log where Hasdtasres="Has Report" and ece_severity > "2"  and hostname not like "%windowsupdate.com" and hostname not like "%microsoft.com" and hostname not like "%dell.com" order by ece_severity desc;
select distinct(hostname) from log where Hasdtasres="Has Report" and hostname not like "%windowsupdate.com" and hostname not like "%microsoft.com" and hostname not like "%dell.com"and ece_severity > "2" order by ece_severity desc;
#######################################################################################################################
Ransomware:

select *  from log where Threat_Description like "%ransom%";

select Threat_Description, Source_IP, Destination_IP, Interested_IP, InterestedHost, Domain_Name, Hostname, URL, Hasdtasres, ece_severity   from log where Threat_Description like "%ransom%";


** need to check TD for "CRILOCK" and others *** -> check smart filter list
select distinct(Threat_Description)  from log WHERE UPPER(Threat_Description) REGEXP 'LOCK|RANSOM|ANDROIDOS_LOCKER|BAT_CRYPTOR|BAT_CRYPVAULT|CRILOCK|CRYPTESLA|JS_DOWNCRYPT|MATSNU|NEMUCOD|PE_VIRLOCK|PHP_CRYPWEB|RANSOM|REVETON|TROJ_ACCDFISA|TROJ_CRIBIT|TROJ_CRITOLOCK|TROJ_CRYP|TROJ_GULCRYPT|TROJ_KOLLAH|TROJ_KOVTER|TROJ_PGPCODER|TROJ_POSHCODER|TSPY_KOVTER|VBUZKY|_CERBER|_LOCKY';

need more data!!!
check past queries in other BAR tool

#######################################################################################################################
Compromised Hosts

select distinct(InterestedHost) from log where attack_phase="Command and Control Communication";

After we have the list of hosts| get other alerts associated with the host:
C2:
LM:

select count(*) from log where interestedhost="";
threat descriptions (unique) - may not have space
attack_phases - C2: X  POE: W  LM: Y  DE: Z
#######################################################################################################################
C2 Info

Hosts with C2 alert:  select distinct(InterestedHost)| count(*) from log where attack_phase="Command and Control Communication" group by InterestedHost order by count(*) desc;

URLs:  select distinct(URL), count(*) from log where attack_phase="Command and Control Communication" and protocol="HTTP" group by URL order by count(*) desc;
Domains: select distinct(hostname), count(*) from log where attack_phase="Command and Control Communication" group by hostname order by count(*) desc;

10.132.200.100
vara-laptop6530
10.132.43.20
ixatc-malvarezb


#######################################################################################################################
Lateral Movement

select distinct(Threat_Description), count(*), source_ip, destination_ip from log where attack_phase="Lateral Movement" group by Threat_Description order by count(*) desc;

hard to pick out the relevant from the noise




#######################################################################################################################
APT Alerts

Alert Names
Hosts with APT Alerts


#######################################################################################################################
Callbacks to Suspicious Objects (URLs, IPs, Domains)

select * from log where threat_description like "%Suspicious Objects%" and threat_description not like "%File%";

######################################################################################################################


select distinct(attack_phase), count(*) from log  group by attack_phase order by count(*) desc;

select distinct(Threat_Description), count(*) from log  group by Threat_Description order by count(*) desc;

## The hosts with the most :)
select distinct(interestedhost), count(*) from log  group by interestedhost order by count(*) desc;


 '''